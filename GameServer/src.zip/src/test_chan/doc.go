// test_chan project doc.go

/*
test_chan document
*/
package main
