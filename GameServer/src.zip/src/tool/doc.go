// tool project doc.go

/*
tool document
*/
package tool
