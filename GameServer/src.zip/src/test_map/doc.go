// test_map project doc.go

/*
test_map document
*/
package main
