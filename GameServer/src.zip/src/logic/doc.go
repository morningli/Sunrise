// logic project doc.go

/*
logic document
*/
package logic
