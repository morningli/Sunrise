// storage project doc.go

/*
storage document
*/
package storage
