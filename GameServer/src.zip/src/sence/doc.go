// sence project doc.go

/*
sence document
*/
package sence
