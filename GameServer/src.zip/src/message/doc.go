// message project doc.go

/*
message document
*/
package message
