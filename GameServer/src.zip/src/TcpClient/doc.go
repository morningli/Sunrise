// TcpClient project doc.go

/*
TcpClient document
*/
package main
