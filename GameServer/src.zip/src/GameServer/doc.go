// GameServer project doc.go

/*
GameServer document
*/
package main
