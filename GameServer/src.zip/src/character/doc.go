// player project doc.go

/*
player document
*/
package character
