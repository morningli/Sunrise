// TimerTest project doc.go

/*
TimerTest document
*/
package main
