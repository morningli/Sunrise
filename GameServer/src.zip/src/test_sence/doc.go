// test_sence project doc.go

/*
test_sence document
*/
package main
